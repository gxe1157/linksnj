<?php defined( 'BASEPATH') OR exit( 'No direct script access allowed'); ?>
<!--start section page body-->
<section class="section-detail-content houzez-page-template">

    <div class="container">
        <div class="page-title breadcrumb-top">
            <div class="row">
                <div class="col-sm-12">
                    <ol class="breadcrumb">
                        <li><a href="index.html"><i class="fa fa-home"></i></a>
                        </li>
                        <li class="active">Buyer FAQS</li>
                    </ol>
                    <div class="page-title-left">
                        <h2>Buyer FAQS</h2>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 container-contentbar">
                <div class="page-main">
                    <div class="white-block ">
                        <article id="post-692" class="post-692 page type-page status-publish hentry">
                            <div class="entry-content">

                                <div class="row row-fluid">
                                    <div class="col-sm-12">
                                        <div class="vc_column-inner ">
                                            <div class="wpb_wrapper">
                                                <div class="wpb_text_column wpb_content_element ">
                                              
                                                <div class="wpb_wrapper">
	
    <!-- begin content -->
    <p><b>Buyer FAQ’s</b></p>
    <p><b>“Questions That Buyers Frequently Ask”</b></p>
    <p><b>Q. Why should I work with a Real Estate Professional to purchase a home?<br> </b><br> <b>A.</b> Real Estate Professionals can save you time and assist you in house hunting by:</p>
    <p>Pre-selecting homes that are within your price range and that meet your requirements for location, size, and style, etc.</p>
    <ul>
    <li>Scheduling appointments for you to preview homes</li>
    <li>Providing advice about financing and the importance of a pre-qualification</li>
    <li>Explaining the sequence of steps leading to a home purchase</li>
    <li>As a basis for comparison, providing current selling prices for homes resembling those homes being considered for purchase</li>
    <li>Obtaining current tax information and other pertinent information in the communities being considered</li>
    <li>Handling negotiations regarding the amount and terms of your offer</li>
    <li>Scheduling requested inspections</li>
    <li>Obtaining a Property Condition Disclosure Form and Lead Paint Disclosure when required of the seller</li>
    <li>Explaining required state and federal forms</li>
    <li>Explaining representation options</li>
    <li>Providing a choice of professionals to help assist you with your process</li>
    <li>Providing information sources you wish to obtain</li>
    </ul>
    <p><b>Q. Should I Work With A Buyer's Agent? A Seller's Agent? A Dual Agent?</b></p>
    <p><b>A.</b> You should understand from the beginning of your relationship with your real estate agent what type of relationship exists. In most states, real estate agents (both brokers and sales associates alike) are required by law to let consumers know whether they represent the buyer or the seller.</p>
    <ul>
    <li>In the past, real estate agents represented the seller exclusively, whether the agent helped a seller to market and sell the home or helped a buyer find and purchase the home. In other words, agents were at one time legally bound to represent the seller in a residential real estate transaction. In that same scenario, the seller paid both the listing agent and the agent who brought the buyer.</li>
    <li>In today's real estate market, you may find that you can choose between a wide variety of options for representation. If you want to sell a home, you can work with a "seller's agent". If you are purchasing a home, you can work with a subagent of the seller's agent and, in many areas, you can engage an exclusive "buyer's agent”.</li>
    <li>An additional situation is dual agency. This type of agency exists when the buyer decides to have the seller's agent prepare the offer on the buyer's behalf. A buyer who elects this situation, and all additional parties to a transaction, should receive full disclosure of representation. In some states, dual agency also affects the real estate professional's fiduciary responsibilities to the seller.</li>
    </ul>
    <p><b>Q. How many homes should I plan to view and how should I make the final decision?</b></p>
    <p>A. Generally you should view a number of homes so you can become familiar with what you can expect to get for your money. When you find a home you really like, it’s a good idea to go back and view at it at different times of day. This will give you greater insight into what it will be like living in the home full time.</p>
    <p><b>Q. What are the different types of home ownership?</b></p>
    <p><b>A.</b> Single-Family: This is the most popular type of homeownership. As the owner of a single-family dwelling, you are totally responsible for paying the mortgage, property taxes and any other carrying expenses including all maintenance costs.</p>
    <p>Condominium &amp; Cooperatives: As an owner of a condominium, the living quarters (apartment townhouse or other unit) are owned in the same way as single-family homeowner.&nbsp; As a co-op owner, you buy a share, or a number of shares, in the corporation that owns or manages the co-op building and the land upon which it is located. Under any of these forms of ownership, a share of the common space, such as gardens, parking areas, and community facilities (e.g. pool, golf course, recreation center and tennis court) is also owned. A monthly maintenance fee for common expenses is paid. The community's Homeowners' Association makes decisions about how the condo or co-op is managed. The association may provide a variety of services and extra features that single-family homeowners often can't afford. However, by-laws and rules of the association must be followed.</p>
    <p>Multi-Family: This style home has separate living quarters for two or more families offering an opportunity to rent one or more units. The owner may be able to use the rent from the tenants to cover his or her own housing costs. These homes are often restricted to certain areas by zoning laws.&nbsp;</p>
    <p><b>Q. When previewing a home, what should I look for?</b></p>
    <p><b>A.</b> In addition to comparing the home to your minimum requirements and wish lists, consider the following:</p>
    <ul>
    <li>Is there enough room for both the present and the future?</li>
    <li>Are there enough bedrooms and bathrooms?</li>
    <li>Is the yard large enough?</li>
    <li>Do you like the floor plan?</li>
    <li>Will your furniture fit in the space? Is there enough storage space?</li>
    <li>Imagine the house in good weather and bad, and in each season. Will you be happy living there year-round?</li>
    </ul>
    <p><b>Q. What should I tell the sales agent about the homes I look at?</b></p>
    <p>A. Tell the sales professional everything you like and don't like about each home you see. Don't be shy about discussing a home's shortcomings. Is the home too small for your needs? Let the sales professional know. Was the home perfect except for the carpeting? Let the sales professional know.&nbsp;</p>
    <p><b>Q. How can I keep track of all the homes that I see?</b></p>
    <p>A. The best way to track the homes you see is to creat an account on our website here. You'll be able to take notes, mark favorites, search, and set up showings all from the convenience of your sofa. &nbsp;</p>
    <p><b>Q. What is the time frame in purchasing a home?&nbsp;</b></p>
    <p><b>A.</b> Once you find the home of your dreams, start to finish it will be around 45 to 90 days.</p>
    <ul>
    <li>Initially the buyer will be pre-qualified by a mortgage representative to establish the price range within which he/she should be looking.</li>
    <li>Once you find your dream house, our agents will type up a contract offer with the price, closing date, mortgage amount and other particulars and will then present the offer to the seller.</li>
    <li>You may receive a counter offer from the seller, and when the terms, price, closing date and items included are agreed upon you will then make an appointment with your attorney. Once your attorney has your contract you have 3 days for an attorney review of your contract.</li>
    <li>During the next week the purchaser will engage a home inspector (engineer) to fully inspect the property including: heating, plumbing, electrical, and structural.&nbsp; In addition to termites and radon testing.&nbsp; Simultaneously the purchaser shall be submitting their mortgage application for the financing of the home.</li>
    <li>Within 45 days (or sooner) of contract your financing will be in place and then your attorney will prepare all the necessary legal documents for closing.</li>
    <li>Start packing! Within a few weeks you will be closing title on your new home.</li>
    </ul>
    <p><b>Q. What do I do if I don’t like my broker or agent?</b></p>
    <p><b>A.</b> Tell the agent right away and find a new one.&nbsp; The best way to find good agents is to ask friends to refer you to someone.&nbsp;</p>
    <p><b>Q. When I've found the home I like, how do I make an offer?</b></p>
    <p>A. When you've found a special house you want to call home, you'll probably feel excited and a bit nervous. Let the sales professional know you're ready to write an "offer to purchase" — a written document that declares how much you are willing to pay for the home provided that certain conditions are met. Because it's a legally binding contract that you will sign and date, it may be a good idea to have a Real Estate Lawyer review it, within the grace period noted in the contract.</p>
    <p>Your offer should have a time limit for the seller to accept it, reject it, or make a counter-offer. If a counter-offer is made, you will have some time to respond. Often, several offers go back and forth until an offer is accepted, or one party decides to end negotiations.&nbsp;</p>
    <p><b>Q. How do I determine an appropriate amount of my initial offer?</b></p>
    <p><b>A.</b> There is really no rule to use in calculating an initial offer. Naturally, the buyer wants the best value and the seller want the best price, but negotiations can be influenced by many factors, such as a seller who may be changing jobs and wants to sell quickly, or a buyer who is set on a specific home.</p>
    <p>After you've looked at the home's features, asked questions, compared properties, and talked about it with your sales professional, you should have a good idea of what the home's value is in the current market. Consider what you can afford, and make an offer that you consider to be fair.</p>
    <p><b>Q. What is the purpose of an attorney review?</b></p>
    <p><b>A.</b> In states where the real estate agent writes the contract, there may be an attorney review period. This specified period allows the attorney to cancel the contract or request it be altered. Both buyer and seller would then have to agree to the revised contract in writing. During this period, either party may void the contract without penalty.</p>
    <p><b>Q. What is a mortgage, and what are the benefits of different kinds of mortgages?</b></p>
    <p><b>A.</b> A mortgage is a loan that a homebuyer obtains directly from a lender to purchase real estate. The mortgage is a lien on the property that secures a promissory note (promise to repay the debt) that states the terms of the loan, including the interest rate and the number of payments.</p>
    <p>The most popular mortgages available to home buyers today can be divided into two general categories: those that offer fixed interest rates and monthly payments, and those in which one or both of those factors are adjustable.</p>
    <p>Fixed-rate/fixed-payment loans are more traditional and remain the most popular home financing method, currently accounting for about two-thirds of all residential mortgages. Their advantages are well-known: you always know what your monthly principal and interest payment will be, so your basic housing cost will remain unaffected by interest-rate changes until the mortgage is paid off.</p>
    <p>Mortgages that entail flexible rates and/or payments have grown in popularity in recent years, primarily during periods of high interest rates and/or rapidly rising home prices. Many, including the popular ARMs (Adjustable Rate Mortgages), offer lower than market initial interest rates that allow buyers a measure of affordability unavailable in fixed-rate loans. The trade-off may be higher interest rates and higher monthly payments later on.</p>
    <p><b>Q. I want to buy a house, what does a mortgage lender consider when reviewing a loan application?<br> </b><br> <b>A.</b> There are three categories of information that lender's look at when reviewing a loan application: (1) the applicant's personal information, (2) the subject property information and (3) the mortgage program information.</p>
    <p>Personal Information: A lender will look at income, assets, debts and credit history to help determine your ability to repay the loan.</p>
    <p>Property Information: An appraiser will compare your home to other similar homes in your area to determine that the loan amount being requested is acceptable to the investors.</p>
    <p>Mortgage Information: There are a wide variety of mortgage programs to help you with your home financing. Programs vary based on factors such as down payment required, repayment terms and length, points, and interest rates. A lender will look at the program you selected as a preferred scenario and verify that you meet all the program criteria. For more information refer to Mortgage Services.</p>
    <p><b>Q. How can I check my credit rating before I apply for a mortgage?</b></p>
    <p><b>A.</b> Your credit rating is based on a combined score generated from three credit bureaus who analyze your credit history, amount of credit available, and recent inquiries to determine what your FICO score will be. For a small fee, you can get your score or review your credit report by going online to www.myfico.com or contacting the credit bureaus directly at:</p>
    <p>Equifax, www.equifax.com, (800) 685 1111&nbsp;<br> Experian, www.experian.com, (888) 397-3742&nbsp;<br> TransUnion, www.transunion.com, (800) 916-8800</p>
    <p><b>Q. Why should I consider paying points?</b></p>
    <p><b>A.</b> Buyers often choose to pay a one-time charge called mortgage “points” in exchange for a lower interest rate. Usually paid at closing, each “point” costs 1% of the mortgage amount, e.g. $2,000 on a $200,000 loan. The lower rate reduces the monthly mortgage payment, and points paid in conjunction with the purchase of a home are generally tax-deductible in the year they’re paid (see tax advisor). Monthly savings will often exceed what was paid in points in just a few years’ time.</p>
    <p><b>Q. What happens if the house I want to purchase does not appraise at the amount expected?</b></p>
    <p><b>A.</b> If the house doesn’t appraise at the amount expected, other alternatives are typically found. A second appraisal may be sought, the buyer may be willing to put more money down, the seller may adjust the price or offer other concessions, or the two sides may negotiate to split the difference between them.</p>
    <p><b>Q. What is title insurance and why do I need it?</b></p>
    <p><b>A.</b> Title insurance assures that you have clear title to the home you’re purchasing. A title search is the primary component of “due diligence,” a process that will be started either by your attorney, if you are using one, or by the title company you choose. The title search determines whether the seller actually owns the property and if there are any claims against it.</p>
    <p><b>Q. Is a homeowner's insurance policy needed?</b><br> <b><br> A.</b> Yes, a paid homeowner's insurance policy (or a paid receipt for one) is generally required at closing.&nbsp;<br> <br> <b>Q. What should I look for on my final walk-through?</b></p>
    <p><b>A.</b> In most cases, you'll be given the opportunity to inspect the home immediately prior to closing. At this time, it's important to check on any work the seller agreed to have done in response to your initial inspection. You should also carefully check the condition of walls and ceilings from which window treatments, pictures, or any other attached furnishings have been removed. If you find any problems, don't hesitate to bring them up at the closing. It's the seller's responsibility to correct them. Buyers should know that this is not a time to re-negotiate but to see that the house is in the condition that it should be when they take ownership of the property.</p>
    <p><b>Q. As a buyer, what documents can I expect to receive on the day of closing?</b><br> <br> <b>A.</b> The buyers will receive the following documents:</p>
    <p>RESPA or HUD 1 Form (itemizes services provided and the fees charged; it is filled out by the closing agent and must be given at closing.)</p>
    <ul>
    <li>Truth-in-Lending Statement</li>
    <li>Mortgage Note</li>
    <li>Mortgage or Deed of Trust</li>
    <li>A binding Sales Contract</li>
    <li>Keys for your NEW HOME!</li>
    </ul>
    <p><b>Q. Is there anything I should do immediately after closing?</b></p>
    <p><b>A.</b> The first thing you'll want to do is have the locks changed. You should call the water company and the electric company and change the name on the account so that you can be billed properly.&nbsp; Also, put your deed and other important paperwork from the closing in a secure place.&nbsp; Even though it's all on file with the county, it's smart to know where your copies are and to have access to them at all times.</p>
    <script language="javascript" type="text/javascript">
    var fixTabs = function (selector) {
        $(selector)
        .find("li a").each(function () {
            var href = $(this).attr("href");
    
            if (href.indexOf("#") != 0) {
                $(this).attr("href", href.substring(href.indexOf("#")));
            }
        })
    };
    
    fixTabs("#menu");
    
    
    </script>
    
                        
                </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <!-- .entry-content -->
                        </article>
                        <!-- #post-## -->
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 container-sidebar ">
                    <aside id="sidebar" class="sidebar-white">
                        <?php $this->load->view('aside/side-bar'); ?>
                    </aside>
                </div>

            </div>

</section>
<!--end section page body-->