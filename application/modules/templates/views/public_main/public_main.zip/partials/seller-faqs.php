<?php defined( 'BASEPATH') OR exit( 'No direct script access allowed'); ?>
<!--start section page body-->
<section class="section-detail-content houzez-page-template">
    <div class="container">
        <div class="page-title breadcrumb-top">
            <div class="row">
                <div class="col-sm-12">
                    <ol class="breadcrumb">
                        <li><a href="index.html"><i class="fa fa-home"></i></a> </li>
                        <li class="active">Seller FAQS</li>
                    </ol>
                    <div class="page-title-left">
                        <h2>Seller FAQS</h2> </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 container-contentbar">
                <div class="page-main">
                    <div class="white-block ">
                        <article id="post-692" class="post-692 page type-page status-publish hentry">
                            <div class="entry-content">
                                <div class="row row-fluid">
                                    <div class="col-sm-12">
                                        <div class="vc_column-inner ">
                                            <div class="wpb_wrapper">
                                                <div class="wpb_text_column wpb_content_element ">
                                                    <div class="wpb_wrapper">
                                                        <!-- begin content -->
                                                        <p><b>Seller FAQ’s</b>
                                                        </p>
                                                        <p><b>“Questions That Sellers Frequently Ask.”</b>
                                                        </p>
                                                        <p><b>Q. Why should I work with a real estate professional to sell my house?</b>
                                                            <br>
                                                            <br> <b>A.</b> Selling a home is a complex transaction that takes time, effort and expertise. The benefits of utilizing the services provided by Marc Stein of Links Residential include:</p>
                                                        <ul>
                                                            <li>As REALTORS®, our agents know the current real estate market, and can help establish a realistic, competitive price, and complete marketing plan specialized for your home.</li>
                                                            <li>Knowledge in determining the approximate net proceeds from the home sale</li>
                                                            <li>Experience in the know-how of adding sales appeal to a home at low or moderate cost.</li>
                                                            <li>The resources to find prospective buyers. Most homeowners prefer to work with a real estate professional so that serious prospects are pre-approved</li>
                                                            <li>Exposure to an even larger market through referrals and marketing techniques.</li>
                                                            <li>Freedom for the seller from the problems of showing the home to prospective buyers. Marc Stein will handle all phone inquiries, makes appointments, and will follows up with buyers.</li>
                                                            <li>Possesses the skills required to merchandise a home effectively.</li>
                                                            <li>Objectivity in responding to possible criticisms by the buyer and in presenting offers and counter-offers until an agreement is reached.</li>
                                                            <li>Providing the seller with the closing procedures by explaining them in advance.</li>
                                                            <li>Submitting the property to the local Multiple Listing Service (MLS), this exposes the property to all REALTOR® members, and expands the range of prospective buyers.</li>
                                                            <li>Initiating, carrying-out and following through on every phase of the important, complex selling transaction.</li>
                                                        </ul>
                                                        <p>&nbsp;</p>
                                                        <p><b>Q. Should I try marketing and selling my house without a broker or agent?</b>
                                                        </p>
                                                        <p><b>A.</b> Many people believe they can save a significant amount of money by selling on their own. In order to do this, you'll need to realistically assess exactly what's involved. The routine parts of the job involve pricing your house accurately, determining whether or not a buyer is qualified, creating and paying for your own advertising, familiarizing yourself with enough basic real estate regulations to understand a real estate contract, and coordinating the details of a closing. One of the best reasons for working with a real estate broker or agent is the vast amount of information they have at their disposal — information that can help make your house sell faster and easier. Professionals know about market trends, houses in your neighborhood, and the people most likely to buy in such neighborhoods. They also know how to reach the largest number of people who may be interested in your house (both through old-fashioned sales skill and the Internet resources of a reputable real estate company), and are trained in areas such as screening potential buyers and negotiating with them. Finally, they're always "on-call," and willing to working at night and on weekends to answer the phone at all hours.</p>
                                                        <p>&nbsp;</p>
                                                        <p><b>Q. What makes a house sell?</b>
                                                        </p>
                                                        <p><b>A.</b> There are many things that make a house desirable.&nbsp; To be as concise as possible, a successful sale requires that you concentrate on six considerations: (1) your sale price, (2) your terms of sale, (3) the condition of your house, (4) its location, (5) its accessibility, and (6) the extent of marketing exposure your house receives. Some of these factors are beyond your control (such as the actual sale price). You can compensate by taking advantage of others (like a new paint job) to make your property as attractive to prospective buyers as possible.</p>
                                                        <p>&nbsp;</p>
                                                        <p><b>Q. When is the best time to list a house for sale?</b>
                                                        </p>
                                                        <p><b>A.</b> The "best" time to list your house is actually as soon as you decide to sell it.</p>
                                                        <p>If you want to get the best price for your house, the key is to give yourself as much time as possible to sell it. More time means more potential buyers can see the house. This should result in more offers; it also gives you time to consider more options if the market is slow or initial interest is low.</p>
                                                        <p>&nbsp;</p>
                                                        <p><b>Q. Is there any seasonality to the market?</b>
                                                        </p>
                                                        <p><b>A.</b> Peak selling seasons vary in different areas of the country, and weather has a lot to do with it. For example, late spring and early fall are the prime listing seasons in many areas because houses tend to "show" better in those months than they do in the heat of summer or the cold of winter. And of course, people like to do their house shopping when the weather is pleasant. But keep in mind that there are also more houses on the market during the prime seasons, so you'll have more competition. So while there is seasonality in the real estate market, it's not something that should dominate your decision on when to sell.</p>
                                                        <p>&nbsp;</p>
                                                        <p><b>Q. What about market conditions — price trends, interest rates, and the economy in general? Should they have any bearing on when I list?</b>
                                                        </p>
                                                        <p><b>A.</b> Probably not. Even if you're under no pressure to sell, waiting for better market conditions is not likely to increase your profit potential.</p>
                                                        <p>&nbsp;</p>
                                                        <p><b>Q. Should I Work With A Buyer's Agent? A Seller's Agent? A Dual Agent?</b>
                                                        </p>
                                                        <p><b>A.</b> You should understand from the beginning of your relationship with your real estate agent what type of relationship exists. In most states, real estate agents (both brokers and sales associates alike) are required by law to let consumers know whether they represent the buyer or the seller.</p>
                                                        <ul>
                                                            <li>In the past, real estate agents represented the seller exclusively, whether the agent helped a seller to market and sell the home or helped a buyer find and purchase the home. In other words, agents were at one time legally bound to represent the seller in a residential real estate transaction. In that same scenario, the seller paid both the listing agent and the agent who brought the buyer.</li>
                                                            <li>In today's real estate market, you may find that you can choose between wide varieties of options for representation. If you want to sell a home, you can work with a "seller's agent". If you are purchasing a home, you can work with a subagent of the seller's agent and, in many areas, you can engage an exclusive "buyer's agent".</li>
                                                            <li>An additional situation is “dual agency”. This type of agency exists when the buyer decides to have the seller's agent prepare the offer on the buyer's behalf. A buyer, who elects this situation, and all additional parties to a transaction, should receive full disclosure of representation. In some states, dual agency also affects the real estate professional's fiduciary responsibilities to the seller.</li>
                                                        </ul>
                                                        <p>&nbsp;</p>
                                                        <p><b>Q. How do I determine the value of my home?</b>
                                                            <br>
                                                            <br> <b>A.</b> A home's value depends on many factors, including its style and size, amenities, condition and, of course, location. In addition, the value of a real estate investment can be affected by market conditions, interest rates, supply and demand, and the overall strength of the economy. As a homeowner, your ability to maintain a consistent understanding of your property's value depends on these factors. In a changing market, it makes financial sense to know your home's worth and to monitor the return on your investment. After all, owning a home is not unlike trading stock; knowing the time to buy and the time to sell can have a significant impact on your investment portfolio.
                                                            <br> Village Homes Realty is a local market expert who keeps up-to-date with changes in the home sales market and can provide a fair estimate of a home's worth. In addition, our agents have access to comparative sales data - another tool that helps determine the value of a home.</p>
                                                        <p>&nbsp;</p>
                                                        <p><b>Q. Why shouldn’t I price my house a little high, since I can always drop the price later?</b>
                                                        </p>
                                                        <p><b>A.</b> That’s a strategy that sounds good – but, in fact, it is more likely to result in a lower price. Here’s why: The first few weeks a house is on the market is when it will have the most activity.&nbsp; If a house is overpriced, it has to compete with houses at that higher price level, which are probably larger houses or have newer or more luxurious features that you are competing against.</p>
                                                        <p>As a result the overpriced home is unlikely to attract an offer. Worse yet, those first weeks are when real estate agents preview the house. If it’s overpriced, they may not even bother to show it to their buyers. Eventually, the seller will have to drop the price – and may end up with an even lower price because buyers will wonder why the house has been on the market so long and may factor that into their offer.</p>
                                                        <p>&nbsp;</p>
                                                        <p><b>Q. What's the difference between fair market value and asking price?</b>
                                                        </p>
                                                        <p><b>A.</b> You can assume that some negotiation will be necessary to reach an agreement with a buyer. The professional who presents you with the results of your Free, No Obligation, Competitive Market Analysis (CMA) will provide all the data that establishes fair market value. Then, based on your own timing and marketplace variables, your real estate professional will be willing to help you establish a competitive pricing strategy. Generally speaking, the owner's asking price — the advertised price of a house when it goes on the market — is set slightly higher than fair market value.</p>
                                                        <p>&nbsp;</p>
                                                        <p><b>Q. How flexible should I be about the asking price?</b>
                                                        </p>
                                                        <p><b>A.</b> Generally, the first three weeks will be the test period of your initial asking price. If you see showings drop off and very few return visits, you may want to consider repositioning your asking price. Most buyers leave room for negotiation when they make an offer. Thus, a certain degree of flexibility is usually called for on the part of both the buyer and seller.</p>
                                                        <p>While it is ultimately your decision to accept or reject an offer, or present a counter-proposal, a good sales professional can be of great assistance to you during the negotiating process. In fact, negotiation is one of the valuable skills a real estate professional can offer you. As negotiations proceed — whether in writing, face-to-face, or by phone — your sales professional will inform you of your options in responding to each offer from the buyer, so you can make an educated decision as to how you want to precede.</p>
                                                        <p>&nbsp;</p>
                                                        <p><b>Q. What should I expect from an open house?</b>
                                                        </p>
                                                        <p><b>A.</b> The open house is another valuable part of the marketing process, offering prospective buyers the chance to view houses in a low-pressure, "browsing" atmosphere. With that in mind, you shouldn't expect it to generate a sale, at least not directly. What you should look for is interest expressed and requests for private showings made to your sales professional in the days following the open house.</p>
                                                        <p>Open houses are always valuable. If many prospective buyers attend, it shows you that the property is attractive and marketable. If very few people show up, it can indicate that the price is too high, and cause you to look for ways to improve curb appeal. Try not to draw your own conclusions — your sales professional will give you a full report on open house activity and offer a professional assessment of its results.</p>
                                                        <p>Sales professionals often hold an open house for other sales professionals shortly after a house is listed. This event, usually held mid-week when real estate people can give it their full attention, can be as important to your efforts as your listing in the local MLS. The more professionals who see your home, the more prospects you're likely to reach.</p>
                                                        <p>&nbsp;</p>
                                                        <p><b>Q. Should the homeowner be present during showings and open houses?</b>
                                                        </p>
                                                        <p><b>A.</b> You should definitely plan to be out of the house during any open house your sales professional has scheduled; the same goes for first showings to prospective buyers. People often feel uncomfortable speaking candidly and asking questions in front of current owners. You want them to feel as free as possible to picture your house as their "dream home."</p>
                                                        <p>&nbsp;</p>
                                                        <p><b>Q. How long should it take to sell?</b>
                                                        </p>
                                                        <p><b>A.</b> Average listing times vary from 30 to 180 days, according to market conditions in a particular region, town, or even neighborhood, and of course, price, terms, condition, location, accessibility and exposure play an even greater role. Selling in any market is easier if you keep time on your side. Most professionals will tell you that allowing yourself at least six months will put you in a position to get a better return from their marketing efforts.</p>
                                                        <p>&nbsp;</p>
                                                        <p><b>Q. What if I can't sell my old house before I have to move?</b>
                                                        </p>
                                                        <p><b>A.</b> This situation can arise for any number of reasons. For instance, getting the job promotion you've been waiting for may mean having to relocate very quickly. Another example: you find your "dream home," and need to get it under contract before it sells to another buyer. Whatever the reason, don't panic. You have some viable alternatives to the worrisome possibility of double mortgage payments. If you don't have to sell in order to buy a new home, consider the advantages and disadvantages of renting your old house.</p>
                                                        <p>&nbsp;</p>
                                                        <p><b>&nbsp;</b>
                                                        </p>
                                                        <p><b>Q. Should I fix my house up before it goes on the market?</b>
                                                        </p>
                                                        <p><b>A.</b> Unless your house is nearly new, chances are you'll want to do some work before putting it on the market.&nbsp; The type and amount of work depends on the price you're asking, the time you have to sell, and the present condition of the house.</p>
                                                        <p>If you're in a hurry to sell, do the "little things" that make your house look better from the outside and show better inside.</p>
                                                        <p>&nbsp;</p>
                                                        <p><b>Q. What is "curb appeal," and how do I create it?</b>
                                                        </p>
                                                        <p><b>A.</b> "Curb appeal" is a common real estate term for everything prospective buyers can see from the street that might make them want to come in and take a look. Improving curb appeal is critical in order to generate traffic. While it does take time, it needn't be difficult or expensive, provided you keep two key words in mind: neat and neutral.</p>
                                                        <p>Neatness sells. New paint, an immaculate lawn, picture-perfect shrubbery, a newly sealed driveway, potted plants at the front door — put them all together, and drive-by shoppers will probably want to see the rest of the house.</p>
                                                        <p>Then, for both the inside and outside of your house, if you're going to repaint, choose neutral colors, and keep clutter and personal knick-knacks, photos, etc. to a minimum. Remember, when a family looks at a house, they're trying to paint a picture of what it would be like as their home. You want to give them as clean a canvas as possible.</p>
                                                        <p>&nbsp;</p>
                                                        <p><b>Q. What should I do to make the house show better?</b>
                                                        </p>
                                                        <p><b>A.</b> First, make your house look as clean and spacious as possible. Remember, people may look behind your doors — closet and crawlspace doors, as well as those to the bedrooms and bathrooms. So get rid of all the clutter; rent a storage space if you need to, hold a garage sale or call a local charity.</p>
                                                        <p>After you've cleaned, try to correct any cosmetic flaws you've noticed. Paint rooms that need it, re-grout tile walls and floors, remove or replace any worn-out carpets. Replace dated faucets, light fixtures, and the handles and knobs on your kitchen drawers and cabinets if needed.</p>
                                                        <p>Finally, as with the outside of your house, try to make it easy for prospective buyers to imagine your house as their home. Clear as much from your walls, shelves, and countertops as you can. Give your prospects plenty of room to dream.</p>
                                                        <p>Use Marc Stein’s show and sell checklist to get specific ideas on how to make your house look its best. Additionally, ask your real estate professional for any company brochures or videos on the subject. Such materials are usually free and extremely helpful to most homeowners.</p>
                                                        <p><b>Q. Should I do the work myself?</b>
                                                        </p>
                                                        <p><b>A.</b> If you have the time and talent, do-it-yourself improvements are the most cost-effective way to go. Painting, wallpapering, replacing cracked trim and old plumbing fixtures — the difference between work done by a competent amateur and a professional is usually time and money. Just make sure you don't tackle something you can't handle — this is no time for "on-the-job training." If you're not experienced, it may be worth calling in a professional.</p>
                                                        <p>Larger jobs involving mechanical systems (heating, electrical, plumbing, etc.), or work that must meet local building codes, are another story. Even if you or the family handyman knows exactly what you're doing, it's not a good idea to engage in this type of work unless you're licensed to do so. Your attempts could make you responsible for more than you realize if something you worked on goes wrong after you sell.</p>
                                                        <script language="javascript" type="text/javascript">
                                                            var fixTabs = function(selector) {
                                                                $(selector).find("li a").each(function() {
                                                                    var href = $(this).attr("href");
                                                                    if (href.indexOf("#") != 0) {
                                                                        $(this).attr("href", href.substring(href.indexOf("#")));
                                                                    }
                                                                })
                                                            };
                                                            fixTabs("#menu");
                                                        </script>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- .entry-content -->
                        </article>
                        <!-- #post-## -->
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 container-sidebar ">
                    <aside id="sidebar" class="sidebar-white">
                        <?php $this->load->view('aside/side-bar'); ?>
                    </aside>
                </div>
            </div>
</section>
<!--end section page body-->