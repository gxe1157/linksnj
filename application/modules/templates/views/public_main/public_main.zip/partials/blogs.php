<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
    <!--start section page body-->
    <section id="section-body">

        <!--start detail content-->
        <section class="section-detail-content blog-page">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-md-8 col-sm-12 container-contentbar">
                        <div class="article-main">
                            <h3>Coming soon...</h3>
                            <p>The links NJ blog will be coming soon, stay tuned!</p>   
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-6 col-md-offset-0 col-sm-offset-3 container-sidebar">
                    <aside id="sidebar" class="sidebar-white">
                        <?php $this->load->view('aside/side-bar'); ?>
                    </aside>
                    </div>
                </div>
            </div>
        </section>
        <!--end detail content-->

    </section>
    <!--end section page body-->


