<?php defined('BASEPATH') OR exit('No direct script access allowed');?>

<!--Head Start-->
<head>
    <title>Links Residential Real Estate</title>
    <!--Meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="Links Residential Real Estate">
    <meta name="description" content="Links Residential Real Estate">

    <link rel="apple-touch-icon" sizes="144x144"
          href="<?= base_url() ?>public/images/favicons/apple-touch-icon.png">
    <link rel="icon" type="image/png"
          href="<?= base_url() ?>public/images/favicons/favicon-32x32.png" sizes="32x32">
    <link rel="icon" type="image/png" 
          href="<?= base_url() ?>public/images/favicons/favicon-16x16.png" sizes="16x16">
    <link rel="manifest" 
          href="<?= base_url() ?>public/images/favicons/manifest.json">
    <link rel="mask-icon" 
          href="<?= base_url() ?>public/images/favicons/safari-pinned-tab.svg" color="#5bbad5">

    <meta name="theme-color" content="#ffffff">

    <script defer src="https://use.fontawesome.com/releases/v5.0.6/js/all.js"></script>

    <!-- Angular goodness -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.5.6/angular.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.5.6/angular-animate.min.js"></script>
    
    <script src="<?= base_url() ?>public/app/app.js"></script>
    <script src="<?= base_url() ?>public/app/services/links.service.js"></script>



    <link href="<?= base_url() ?>public/css/bootstrap.css" 
          rel="stylesheet" type="text/css" />
    <link href="<?= base_url() ?>public/css/bootstrap-select.css" 
          rel="stylesheet" type="text/css" />
    <link href="<?= base_url() ?>public/css/font-awesome.css" 
          rel="stylesheet" type="text/css" />
    <link href="<?= base_url() ?>public/css/slick.css"
          rel="stylesheet" type="text/css" />
    <link href="<?= base_url() ?>public/css/slick-theme.css"
          rel="stylesheet" type="text/css" />
    <link href="<?= base_url() ?>public/css/owl.carousel.css" 
          rel="stylesheet" type="text/css" />
    <link href="<?= base_url() ?>public/css/animate.css" 
          rel="stylesheet" type="text/css" />          
    <link href="<?= base_url() ?>public/css/jquery-ui.css" 
          rel="stylesheet" type="text/css" />
    <link href="<?= base_url() ?>public/css/styles.css" 
          rel="stylesheet" type="text/css" />

    <style type="text/css">
        [ng\:cloak],[ng-cloak],[data-ng-cloak],[x-ng-cloak],.ng-cloak,.x-ng-cloak,.ng-hide:not(.ng-hide-animate){display:none !important;}ng\:form{display:block;}
    </style>
</head>

<!-- contact an agent -->
<div class="modal fade" id="pop-login" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><i class="fas fa-times"></i></button>
            </div>
            <div class="modal-body login-block">
                <h3 class="light-font text-center">Contact an agent</h3>
                <p>It's free with no obligation - cancel anytime</p>

                <div class="tab-content">
                    <div class="tab-pane fade in active">
                        <form name="contactform" method="POST"
                              action='links_property/contact_agent' >

                         <div class="form-group field-group">
                                <div class="input-icon input-calendar">
                                    <input name="appmnt_date" id="appmnt_date" placeholder="Date">

                        <div class='appmnt_date' style="color:red; font-weight: regular;"></div>
             
                                </div>
                                <div class="input-icon input-user">
                                    <input name="fullname" id="fullname" placeholder="Full Name">

                        <div class='fullname' style="color:red; font-weight: regular;"></div>

                                </div>
                                <div class="input-email input-icon">
                                    <input name="email" id="email" placeholder="Email">

                        <div class='email' style="color:red; font-weight: regular;"></div>

                                    
                                </div>
                                <div class="input-icon input-phone">
                                    <input name="phone" id="Phone" placeholder="Phone">

                        <div class='phone' style="color:red; font-weight: regular;"></div>
                                   
                                </div>
                                <div>
                                    <textarea class="form-control" name="message" id="message" placeholder="Questions / Comments" rows="3"></textarea>

                        <div class='message' style="color:red; font-weight: regular;"></div>                                    
                                </div>
                                <div style="margin: 20px 0;" class="text-center">
                                    Are you working with a links agent?
                                    <select name="links_agent" id="links_agent">
                                        <option value=''>Select...</option>
                                        <option option='yes'>Yes</option>
                                        <option option='no'>No</option>
                                    </select>

                        <div class='links_agent' style="color:red; font-weight: regular;"></div>
                                    
                                </div>
                                <div style="margin: 20px 0;" class="text-center">
                                  <select name="availability" id="availability">
                                    <option value="">What is your availability?</option>
                                    <option value="2">In the Morning</option>
                                    <option value="3">In the Afternoon</option>
                                    <option value="4">In the Evening</option>
                                    <option value="5">I'm Pretty Flexible</option>
                                  </select>

                        <div class='availability' style="color:red; font-weight: regular;"></div>
                               
                                </div>
                                <div style="margin: 20px 0;" class="text-center">
                                    <select name="select_agent" id="select_agent">
                                        <option value="">Select an agent</option>
                                        <option value="1">Alain Spira</option>
                                        <option value="2">Aleshia Jijon</option>
                                        <option value="3">Alicia Pugh</option>
                                        <option value="4">Brigitte Hauyon</option>
                                        <option value="5">Bruce Elichman</option>
                                        <option value="6">Carlos Ortiz</option>
                                        <option value="7">Carol Urena</option>
                                        <option value="8">Cathy Denis</option>
                                        <option value="9">Dalia Sakai</option>
                                        <option value="10">Dara Klatsky</option>
                                        <option value="11">Deborah Pearlman</option>
                                        <option value="12">Donald Callwood</option>
                                        <option value="13">Dov Mittelman</option>
                                        <option value="14">Gnesha Shain</option>
                                        <option value="15">Johanna Cogan</option>
                                        <option value="16">Julieanne DesJardins</option>
                                        <option value="17">Kenneth Grier</option>
                                        <option value="18">Kenneth Schwartz</option>
                                        <option value="19">Liora Kirsch</option>
                                        <option value="20">Luis Gutierrez</option>
                                        <option value="21">Malka Abrahams</option>
                                        <option value="22">Malkie Benson</option>
                                        <option value="23">Marc Stein</option>
                                        <option value="24">Michelle Padilla</option>
                                        <option value="25">Michelle Wasserlauf</option>
                                        <option value="26">Nina Eizikovitz</option>
                                        <option value="27">Rena Strulowitz</option>
                                        <option value="28">Roger Mejia-Lopez</option>
                                        <option value="29">Sara Landerer</option>
                                        <option value="30">Suzanne Packer</option>
                                        <option value="31">Tatiana Leon</option>
                                        <option value="32">Zeevyah Benoff</option>
                                    </select>

                        <div class='select_agent' style="color:red; font-weight: regular;"></div>
                                </div>
                                <input type="submit" class="btn btn-primary btn-block btnSubmit" value="Submit">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

  <div id="site-wrapper" class="<?php echo $this->router->fetch_class() ?>">
  <div id="site-canvas">

  

<div id="site-menu">
  
  <div class="side-logo">
    <a href="<?= base_url() ?>"><img src="<?= base_url() ?>public/images/Links-logo.png" alt="logo"></a>
  </div>

  <section>
    <h4>
      <a href="#" data-toggle="modal" data-target="#pop-login">
        <i class="fas fa-user"></i>Contact an agent!
      </a>
    </h4>
  </section>

<hr />
<hr />


    <section>
        <h4>More Info</h4>

        <ul class="sub-menu">
            <li>
                <a href="
                   <?= base_url() ?>about-us">
                    About
                </a>
            </li>
            <li>
                <a href="
                    <?= base_url() ?>buyer-faqs">
                    Buyer FAQS
                </a>
            </li>
            <li>
                <a href="
                    <?= base_url() ?>seller-faqs">
                    Seller FAQS
                </a>
            </li>
            </ul>
</section>

<hr />
<hr />


    <section>
        <h4>Coming soon</h4>

        <ul class="sub-menu">
            <li>
                <a href="
                   <?= base_url() ?>nyc">
                    Links NYC
                </a>
            </li>
            <li>
                <a href="
                    <?= base_url() ?>commercial">
                    Links Commercial Real Estate 
                </a>
            </li>
            <li>
                <a href="
                    <?= base_url() ?>seller-faqs">
                    Links Property Management 
                </a>
            </li>
            </ul>
</section>


  
</div>

    <div class="modal fade" id="pop-reset-pass" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-header">
                <ul class="login-tabs">
                    <li class="active">Reset Password</li>
                </ul>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><i class="fa fa-close"></i></button>
            </div>
            <div class="modal-body">
                <p>Please enter your username or email address. You will receive a link to create a new password via email.</p>
                <form>
                    <div class="form-group">
                        <div class="input-user input-icon">
                            <input placeholder="Enter your username or email" class="form-control">
                        </div>
                    </div>
                    <button class="btn btn-primary btn-block">Get new password</button>
                </form>
            </div>
        </div>
    </div>
    </div>
    <!-- model signin / register -->

<!--Head End-->


