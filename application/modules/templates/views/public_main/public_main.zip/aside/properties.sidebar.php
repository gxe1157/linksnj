<!-- NG MODEL SEARCH -->
<input type="text" ng-model="search">
                        <ul>
                            <li ng-show="!filteredProps.length">no results found</li>
                            <li ng-repeat="property in filteredProps = (hc.properties | filter:search)">
                            <div class="item-wrap" style="width:300px">
                                            <div class="property-item item-grid">
                                                <div class="figure-block">
                                                    <figure class="item-thumb">
                                                        <div class="label-wrap hide-on-list">
                                                            <div class="label-status label label-default">For Sale</div>
                                                        </div>
                                                        <span class="label-featured label label-success">Featured</span>
                                                        <div class="price hide-on-list">
                                                            <h3 ng-bind="property.listPrice"></h3>
                                                        </div>
                                                        <a href="http://links.411mysite.com/property/1005252">
                                                        </a>
                                                        <figcaption class="thumb-caption cap-actions clearfix">
                                                            <div class="pull-right">
                                                                <ul class="list-unstyled actions">
                                                                    <li class="share-btn">
                                                                        <div class="share_tooltip fade">
                                                                            <a href="#" target="_blank"><i class="fa fa-facebook"></i></a>
                                                                            <a href="#" target="_blank"><i class="fa fa-twitter"></i></a>
                                                                            <a href="#" target="_blank"><i class="fa fa-google-plus"></i></a>
                                                                            <a href="#" target="_blank"><i class="fa fa-pinterest"></i></a>
                                                                        </div>
                                                                        <span data-toggle="tooltip" data-placement="top" title="" data-original-title="share"><i class="fa fa-share-alt"></i></span>
                                                                    </li>
                                                                    <li>
                                                                            <span data-toggle="tooltip" data-placement="top" title="" data-original-title="Favorite">
                                                                                <i class="fa fa-heart-o"></i>
                                                                            </span>
                                                                    </li>
                                                                    <li>
                                                                            <span data-toggle="tooltip" data-placement="top" title="" data-original-title="Photos (12)">
                                                                                <i class="fa fa-camera"></i>
                                                                            </span>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </figcaption>
                                                    </figure>
                                                </div>
                                                <div class="item-body">

                                                    <div class="body-left">
                                                        <div class="info-row">
                                                            <div class="rating">
                                                                <span data-title="Average Rate: 4.67 / 5" class="bottom-ratings tip"><span class="fa fa-star-o"></span><span class="fa fa-star-o"></span><span class="fa fa-star-o"></span><span class="fa fa-star-o"></span><span class="fa fa-star-o"></span><span style="width: 70%" class="top-ratings"><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span></span></span>
                                                                <span class="star-text-right">15 Ratings</span>
                                                            </div>
                                                            <h2 class="property-title"><a href="#">Listing #: 1005252</a></h2>
                                                            <h4 class="property-location" ng-bind="property.address_streetName">
                                                                                                                          </h4>
                                                        </div>
                                                        <div class="table-list full-width info-row">
                                                            <div class="cell">
                                                                <div class="info-row amenities">
                                                                    <p>
                                                                        <span>Beds: 3</span>
                                                                        <span>Baths: 2</span>
                                                                        <span>Sqft: 1,965</span>
                                                                    </p>
                                                                    <p>Single Family Home</p>
                                                                </div>
                                                            </div>
                                                            <div class="cell">
                                                                <div class="phone">
                                                                    <a href="#" class="btn btn-primary">Details <i class="fa fa-angle-right fa-right"></i></a>
                                                                    <p><a href="#">+1 (786) 225-0199</a></p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                            <div class="item-foot date hide-on-list">
                                                <div class="item-foot-left">
                                                    <p><i class="fa fa-user"></i> <a href="#">Links Residential</a></p>
                                                </div>
                                                <div class="item-foot-right">
                                                    <p><i class="fa fa-calendar"></i> 12 Days ago </p>
                                                </div>
                                            </div>
                                        </div>


                            </li>
                        </ul>