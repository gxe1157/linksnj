<?php defined( 'BASEPATH') OR exit( 'No direct script access allowed'); ?>
<!--start advanced search section-->
<section class="advanced-search advance-search-header" data-spy="affix" data-offset-top="200" ng-controller="searchController as sc">
    <div class="container w-100">
        <div class="row">
            <div class="col-sm-12">
                <form>
                    <div class="form-group search-long">
                        <div class="search">
                            <div class="input-search input-icon">
                                <input ng-model="searchQuery" class="form-control" type="text" placeholder="Search for a property by town" ng-keyup="sc.searchProperty(searchQuery)">
                                <div id="auto_complete_ajax" class="auto-complete ng-hide" ng-hide="!searchQuery">
                                    <ul>
                                        <li class="ng-hide" ng-show="searchQuery && !sc.autoComplete.length && !sc.loading">
                                            <span>No results found <a href="">Try our counties pages</a></span>
                                        </li>
                                        <li ng-repeat="results in sc.autoComplete">
                                            <a target="_self" ng-href="{{'http://s223809.gridserver.com/county?town=' + results.AREANAME + '&county=' + results.COUNTY}}">
                                                <span ng-bind="::results.AREANAME + ', ' + results.COUNTY + ' county'"> </span>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
<!--                            <div class="advance-btn-holder">
                                <button class="advance-btn btn" type="button"><i class="fas fa-cog"></i> Advanced</button>
                            </div>-->
                        </div>
                        <div class="search-btn">
                            <button class="btn btn-primary">Go</button>
                        </div>
                    </div>
                    <div class="advance-fields">
                        <div class="row">
                            <div class="col-sm-3 col-xs-6">
                                <div class="form-group">
                                    <select class="selectpicker" data-live-search="true" data-live-search-style="begins" title="Status">
                                        <option>Status 1</option>
                                        <option>Status 2</option>
                                        <option>Status 3</option>
                                        <option>Status 4</option>
                                        <option>Status 5</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-3 col-xs-6">
                                <div class="form-group">
                                    <select class="selectpicker" data-live-search="true" data-live-search-style="begins" title="Property Type">
                                        <option>Property Type 1</option>
                                        <option>Property Type 2</option>
                                        <option>Property Type 3</option>
                                        <option>Property Type 4</option>
                                        <option>Property Type 5</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-3 col-xs-6">
                                <div class="form-group">
                                    <select class="selectpicker" data-live-search="true" data-live-search-style="begins" title="Beds">
                                        <option>01</option>
                                        <option>02</option>
                                        <option>03</option>
                                        <option>04</option>
                                        <option>05</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-3 col-xs-6">
                                <div class="form-group">
                                    <select class="selectpicker" data-live-search="true" data-live-search-style="begins" title="Baths">
                                        <option>01</option>
                                        <option>02</option>
                                        <option>03</option>
                                        <option>04</option>
                                        <option>05</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-3 col-xs-6">
                                <div class="form-group">
                                    <select class="selectpicker" data-live-search="true" data-live-search-style="begins" title="Min Price">
                                        <option>$100</option>
                                        <option>$100</option>
                                        <option>$100</option>
                                        <option>$100</option>
                                        <option>$100</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-3 col-xs-6">
                                <div class="form-group">
                                    <select class="selectpicker" data-live-search="true" data-live-search-style="begins" title="Max Price">
                                        <option>$100</option>
                                        <option>$100</option>
                                        <option>$100</option>
                                        <option>$100</option>
                                        <option>$100</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-3 col-xs-6">
                                <div class="form-group">
                                    <select class="selectpicker" data-live-search="true" data-live-search-style="begins" title="Min Areas (Sqft)">
                                        <option>$100</option>
                                        <option>$100</option>
                                        <option>$100</option>
                                        <option>$100</option>
                                        <option>$100</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-3 col-xs-6">
                                <div class="form-group">
                                    <select class="selectpicker" data-live-search="true" data-live-search-style="begins" title="Max Areas (Sqft)">
                                        <option>$100</option>
                                        <option>$100</option>
                                        <option>$100</option>
                                        <option>$100</option>
                                        <option>$100</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-12 col-xs-12 features-list">
                                <label class="text-uppercase title">Other Features</label>
                                <div class="clearfix"></div>
                                <label class="checkbox-inline">
                                    <input type="checkbox" value="option1"> Feature </label>
                                <label class="checkbox-inline">
                                    <input type="checkbox" value="option2"> Feature </label>
                                <label class="checkbox-inline">
                                    <input type="checkbox" value="option3"> Feature </label>
                                <label class="checkbox-inline">
                                    <input type="checkbox" value="option1"> Feature </label>
                                <label class="checkbox-inline">
                                    <input type="checkbox" value="option2"> Feature </label>
                                <label class="checkbox-inline">
                                    <input type="checkbox" value="option3"> Feature </label>
                                <label class="checkbox-inline">
                                    <input type="checkbox" value="option1"> Feature </label>
                                <label class="checkbox-inline">
                                    <input type="checkbox" value="option2"> Feature </label>
                                <label class="checkbox-inline">
                                    <input type="checkbox" value="option3"> Feature </label>
                                <label class="checkbox-inline">
                                    <input type="checkbox" value="option1"> Feature </label>
                                <label class="checkbox-inline">
                                    <input type="checkbox" value="option2"> Feature </label>
                                <label class="checkbox-inline">
                                    <input type="checkbox" value="option3"> Feature </label>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<!--end advanced search section-->
